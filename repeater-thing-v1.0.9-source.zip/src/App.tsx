import { useEffect, useState, useMemo } from 'react'
import { DeskThing } from '@deskthing/client'

const deskthing = DeskThing

// ============================================
// TYPES
// ============================================
interface Repeater {
  Callsign: string
  Frequency: string
  Input_Freq: string
  PL: string
  TSQ: string
  Nearest_City: string
  County: string
  State: string
  Use: string
  distance?: number
  band?: string
  modes?: string[]
  // Additional fields from API
  Landmark?: string
  Affiliate?: string
  Coverage?: string
  ARES?: string
  RACES?: string
  SKYWARN?: string
  Canopy?: string
  Notes?: string
  Last_Update?: string
}

interface LocationInfo {
  state: string
  city?: string
  lat: number
  lng: number
}

type SortOption = 'distance' | 'frequency'

// ============================================
// BAND COLOR MAP
// ============================================
const bandColors: Record<string, string> = {
  '10m': 'bg-red-600',
  '6m': 'bg-orange-500',
  '2m': 'bg-green-600',
  '1.25m': 'bg-teal-500',
  '70cm': 'bg-blue-600',
  '33cm': 'bg-purple-600',
  '23cm': 'bg-pink-600',
  'other': 'bg-gray-600'
}

const modeColors: Record<string, string> = {
  'FM': 'bg-emerald-700',
  'DMR': 'bg-rose-700',
  'D-Star': 'bg-sky-700',
  'Fusion': 'bg-violet-700',
  'P25': 'bg-amber-700',
  'NXDN': 'bg-lime-700'
}

// ============================================
// TOGGLE BUTTON COMPONENT (for multi-select)
// ============================================
function ToggleButton({ 
  active, 
  onClick, 
  children, 
  color = 'bg-gray-700'
}: { 
  active: boolean
  onClick: () => void
  children: React.ReactNode
  color?: string
}) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
        active 
          ? `${color} text-white ring-2 ring-white/50` 
          : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700/50'
      }`}
    >
      {children}
    </button>
  )
}

// ============================================
// REPEATER DETAIL MODAL
// ============================================
function RepeaterDetail({ repeater, onClose }: { repeater: Repeater; onClose: () => void }) {
  const bandColor = bandColors[repeater.band || 'other'] || bandColors.other
  
  return (
    <div 
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3"
      onClick={onClose}
    >
      <div 
        className="bg-gray-900 rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto border border-gray-700 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-gray-900 border-b border-gray-700 p-4 flex justify-between items-start">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className={`${bandColor} px-3 py-1.5 rounded-lg text-base font-bold`}>
                {repeater.band || '?'}
              </span>
              <h2 className="text-2xl font-bold text-white">{repeater.Callsign}</h2>
            </div>
            <div className="text-blue-400 font-semibold text-lg">
              {repeater.distance !== undefined ? `${repeater.distance} miles away` : ''}
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white p-3 -mr-2 -mt-2"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Frequency Section */}
          <div className="bg-gray-800 rounded-xl p-4">
            <h3 className="text-gray-400 text-base mb-2">Frequency</h3>
            <div className="text-4xl font-mono font-bold text-amber-400 mb-2">
              {repeater.Frequency} <span className="text-xl text-gray-500">MHz</span>
            </div>
            {repeater.Input_Freq && (
              <div className="text-xl text-gray-300">
                Input: <span className="font-mono">{repeater.Input_Freq}</span> MHz
              </div>
            )}
          </div>
          
          {/* Tones Section */}
          <div className="bg-gray-800 rounded-xl p-4">
            <h3 className="text-gray-400 text-base mb-3">Tones</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-gray-500 text-base">TX Tone (PL)</div>
                <div className="text-2xl font-mono text-green-400">
                  {repeater.PL || 'None'}
                </div>
              </div>
              <div>
                <div className="text-gray-500 text-base">RX Tone (TSQ)</div>
                <div className="text-2xl font-mono text-cyan-400">
                  {repeater.TSQ || 'None'}
                </div>
              </div>
            </div>
          </div>
          
          {/* Location Section */}
          <div className="bg-gray-800 rounded-xl p-4">
            <h3 className="text-gray-400 text-base mb-2">Location</h3>
            <div className="text-xl text-white mb-1">
              📍 {repeater.Nearest_City}
            </div>
            <div className="text-gray-400 text-lg">
              {repeater.County && `${repeater.County} County, `}{repeater.State}
            </div>
            {repeater.Landmark && (
              <div className="text-gray-500 text-base mt-2">
                📌 {repeater.Landmark}
              </div>
            )}
          </div>
          
          {/* Modes Section */}
          <div className="bg-gray-800 rounded-xl p-4">
            <h3 className="text-gray-400 text-base mb-3">Modes</h3>
            <div className="flex flex-wrap gap-2">
              {repeater.modes?.map((mode) => (
                <span
                  key={mode}
                  className={`${modeColors[mode] || 'bg-gray-600'} px-4 py-2 rounded-lg text-base font-semibold`}
                >
                  {mode}
                </span>
              ))}
            </div>
          </div>
          
          {/* Access Section */}
          <div className="bg-gray-800 rounded-xl p-4">
            <h3 className="text-gray-400 text-base mb-2">Access</h3>
            <div className={`text-2xl font-semibold ${repeater.Use === 'OPEN' ? 'text-green-400' : 'text-yellow-400'}`}>
              {repeater.Use || 'OPEN'}
            </div>
          </div>
          
          {/* Affiliations */}
          {(repeater.ARES === 'Yes' || repeater.RACES === 'Yes' || repeater.SKYWARN === 'Yes') && (
            <div className="bg-gray-800 rounded-xl p-4">
              <h3 className="text-gray-400 text-base mb-3">Affiliations</h3>
              <div className="flex flex-wrap gap-2">
                {repeater.ARES === 'Yes' && (
                  <span className="bg-red-800 px-4 py-2 rounded-lg text-base font-semibold">ARES</span>
                )}
                {repeater.RACES === 'Yes' && (
                  <span className="bg-blue-800 px-4 py-2 rounded-lg text-base font-semibold">RACES</span>
                )}
                {repeater.SKYWARN === 'Yes' && (
                  <span className="bg-yellow-800 px-4 py-2 rounded-lg text-base font-semibold">SKYWARN</span>
                )}
              </div>
            </div>
          )}
          
          {/* Notes */}
          {repeater.Notes && (
            <div className="bg-gray-800 rounded-xl p-4">
              <h3 className="text-gray-400 text-base mb-2">Notes</h3>
              <div className="text-gray-300 text-base leading-relaxed">
                {repeater.Notes}
              </div>
            </div>
          )}
          
          {/* Last Updated */}
          {repeater.Last_Update && (
            <div className="text-center text-gray-500 text-base">
              Last updated: {repeater.Last_Update}
            </div>
          )}
        </div>
        
        {/* Close button at bottom */}
        <div className="sticky bottom-0 bg-gray-900 border-t border-gray-700 p-4">
          <button
            onClick={onClose}
            className="w-full py-4 bg-gray-700 hover:bg-gray-600 rounded-xl text-white text-lg font-semibold transition-all"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================
// REPEATER CARD COMPONENT
// ============================================
function RepeaterCard({ repeater, onClick }: { repeater: Repeater; onClick: () => void }) {
  const bandColor = bandColors[repeater.band || 'other'] || bandColors.other
  
  return (
    <div 
      className="bg-gray-800/80 rounded-xl p-4 border border-gray-700/50 cursor-pointer hover:bg-gray-700/80 hover:border-gray-600 transition-all active:scale-[0.98]"
      onClick={onClick}
    >
      {/* Header: Callsign + Distance */}
      <div className="flex justify-between items-start mb-1">
        <div className="flex items-center gap-2">
          <span className={`${bandColor} px-2 py-0.5 rounded-lg text-base font-bold`}>
            {repeater.band || '?'}
          </span>
          <h3 className="text-xl font-bold text-white">{repeater.Callsign}</h3>
        </div>
        <span className="text-blue-400 font-bold text-lg">
          {repeater.distance !== undefined ? `${repeater.distance} mi` : ''}
        </span>
      </div>
      
      {/* Frequency Info */}
      <div className="flex items-baseline gap-2 mb-1">
        <span className="text-3xl font-mono font-bold text-amber-400">
          {repeater.Frequency}
        </span>
        <span className="text-gray-500 text-base">MHz</span>
      </div>
      
      {/* Tones */}
      <div className="flex gap-4 mb-1 text-base">
        {repeater.PL && repeater.PL !== '' && (
          <div className="flex items-center gap-1">
            <span className="text-gray-500">TX:</span>
            <span className="text-green-400 font-mono font-bold">{repeater.PL}</span>
          </div>
        )}
        {repeater.TSQ && repeater.TSQ !== '' && (
          <div className="flex items-center gap-1">
            <span className="text-gray-500">RX:</span>
            <span className="text-cyan-400 font-mono font-bold">{repeater.TSQ}</span>
          </div>
        )}
        {repeater.Input_Freq && (
          <div className="flex items-center gap-1">
            <span className="text-gray-500">In:</span>
            <span className="text-gray-300 font-mono">{repeater.Input_Freq}</span>
          </div>
        )}
      </div>
      
      {/* Location */}
      <div className="text-gray-400 text-base mb-1">
        📍 {repeater.Nearest_City}{repeater.County ? `, ${repeater.County}` : ''}
      </div>
      
      {/* Modes */}
      <div className="flex flex-wrap gap-1.5">
        {repeater.modes?.map((mode) => (
          <span
            key={mode}
            className={`${modeColors[mode] || 'bg-gray-600'} px-2 py-0.5 rounded-lg text-base font-bold`}
          >
            {mode}
          </span>
        ))}
        {repeater.Use && repeater.Use !== 'OPEN' && (
          <span className="bg-yellow-700 px-2 py-0.5 rounded-lg text-base font-bold">
            {repeater.Use}
          </span>
        )}
      </div>
    </div>
  )
}

// ============================================
// FILTER MODAL
// ============================================
function FilterModal({ 
  onClose,
  sortBy,
  setSortBy,
  maxDistance,
  setMaxDistance,
  selectedBands,
  toggleBand,
  selectedModes,
  toggleMode,
  availableBands,
  availableModes,
  clearFilters,
  hasActiveFilters
}: { 
  onClose: () => void
  sortBy: SortOption
  setSortBy: (sort: SortOption) => void
  maxDistance: number
  setMaxDistance: (dist: number) => void
  selectedBands: Set<string>
  toggleBand: (band: string) => void
  selectedModes: Set<string>
  toggleMode: (mode: string) => void
  availableBands: string[]
  availableModes: string[]
  clearFilters: () => void
  hasActiveFilters: boolean
}) {
  return (
    <div 
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3"
      onClick={onClose}
    >
      <div 
        className="bg-gray-900 rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto border border-gray-700 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-gray-900 border-b border-gray-700 p-4 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-white flex items-center gap-3">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
            </svg>
            Filters
          </h2>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white p-3 -mr-2"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        {/* Content */}
        <div className="p-4 space-y-5">
          {/* Distance Section */}
          <div className="bg-gray-800 rounded-xl p-4">
            <h3 className="text-gray-400 text-base mb-3">Maximum Distance</h3>
            <div className="text-4xl font-bold text-blue-400 text-center mb-4">
              {maxDistance} <span className="text-xl text-gray-500">miles</span>
            </div>
            <input
              type="range"
              min="10"
              max="200"
              step="10"
              value={maxDistance}
              onChange={(e) => setMaxDistance(parseInt(e.target.value))}
              className="w-full h-4 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-sm text-gray-500 mt-2">
              <span>10 mi</span>
              <span>100 mi</span>
              <span>200 mi</span>
            </div>
          </div>
          
          {/* Sort Section */}
          <div className="bg-gray-800 rounded-xl p-4">
            <h3 className="text-gray-400 text-base mb-3">Sort By</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setSortBy('distance')}
                className={`py-4 px-4 rounded-xl text-lg font-semibold transition-all ${
                  sortBy === 'distance'
                    ? 'bg-blue-600 text-white ring-2 ring-blue-400'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                📍 Distance
              </button>
              <button
                onClick={() => setSortBy('frequency')}
                className={`py-4 px-4 rounded-xl text-lg font-semibold transition-all ${
                  sortBy === 'frequency'
                    ? 'bg-blue-600 text-white ring-2 ring-blue-400'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                📶 Frequency
              </button>
            </div>
          </div>
          
          {/* Bands Section */}
          <div className="bg-gray-800 rounded-xl p-4">
            <h3 className="text-gray-400 text-base mb-3">
              Bands {selectedBands.size > 0 && <span className="text-blue-400">({selectedBands.size} selected)</span>}
            </h3>
            <div className="flex flex-wrap gap-2">
              {availableBands.map((band) => (
                <button
                  key={band}
                  onClick={() => toggleBand(band)}
                  className={`px-5 py-3 rounded-xl text-base font-semibold transition-all ${
                    selectedBands.has(band)
                      ? `${bandColors[band] || 'bg-gray-600'} text-white ring-2 ring-white/50`
                      : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
                  }`}
                >
                  {band}
                </button>
              ))}
              {availableBands.length === 0 && (
                <span className="text-gray-500 text-base">No bands available</span>
              )}
            </div>
            <p className="text-sm text-gray-500 mt-3">
              Tap to select/deselect. No selection = show all bands.
            </p>
          </div>
          
          {/* Modes Section */}
          <div className="bg-gray-800 rounded-xl p-4">
            <h3 className="text-gray-400 text-base mb-3">
              Modes {selectedModes.size > 0 && <span className="text-blue-400">({selectedModes.size} selected)</span>}
            </h3>
            <div className="flex flex-wrap gap-2">
              {availableModes.map((mode) => (
                <button
                  key={mode}
                  onClick={() => toggleMode(mode)}
                  className={`px-5 py-3 rounded-xl text-base font-semibold transition-all ${
                    selectedModes.has(mode)
                      ? `${modeColors[mode] || 'bg-gray-600'} text-white ring-2 ring-white/50`
                      : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
                  }`}
                >
                  {mode}
                </button>
              ))}
              {availableModes.length === 0 && (
                <span className="text-gray-500 text-base">No modes available</span>
              )}
            </div>
            <p className="text-sm text-gray-500 mt-3">
              Tap to select/deselect. No selection = show all modes.
            </p>
          </div>
          
          {/* Clear Filters */}
          {hasActiveFilters && (
            <button
              onClick={clearFilters}
              className="w-full py-4 bg-gray-700 hover:bg-gray-600 rounded-xl text-gray-300 text-lg font-semibold transition-all"
            >
              ✕ Clear All Filters
            </button>
          )}
        </div>
        
        {/* OK Button */}
        <div className="sticky bottom-0 bg-gray-900 border-t border-gray-700 p-4">
          <button
            onClick={onClose}
            className="w-full py-5 bg-blue-600 hover:bg-blue-500 rounded-xl text-white text-xl font-bold transition-all"
          >
            OK
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================
// MAIN APP COMPONENT
// ============================================
function App() {
  const [repeaters, setRepeaters] = useState<Repeater[]>([])
  const [location, setLocation] = useState<LocationInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  
  // Filters
  const [sortBy, setSortBy] = useState<SortOption>('distance')
  const [selectedBands, setSelectedBands] = useState<Set<string>>(new Set())
  const [selectedModes, setSelectedModes] = useState<Set<string>>(new Set())
  const [maxDistance, setMaxDistance] = useState<number>(50) // Default 50 miles
  const [showFilters, setShowFilters] = useState(false)
  const [selectedRepeater, setSelectedRepeater] = useState<Repeater | null>(null)

  // Available bands and modes from data
  const availableBands = useMemo(() => {
    const bands = new Set(repeaters.map(r => r.band).filter(Boolean) as string[])
    return Array.from(bands).sort()
  }, [repeaters])

  const availableModes = useMemo(() => {
    const modes = new Set(repeaters.flatMap(r => r.modes || []))
    return Array.from(modes).sort()
  }, [repeaters])

  // Toggle band selection
  const toggleBand = (band: string) => {
    setSelectedBands(prev => {
      const next = new Set(prev)
      if (next.has(band)) {
        next.delete(band)
      } else {
        next.add(band)
      }
      return next
    })
  }

  // Toggle mode selection
  const toggleMode = (mode: string) => {
    setSelectedModes(prev => {
      const next = new Set(prev)
      if (next.has(mode)) {
        next.delete(mode)
      } else {
        next.add(mode)
      }
      return next
    })
  }

  // Filtered and sorted repeaters
  const filteredRepeaters = useMemo(() => {
    let result = [...repeaters]
    
    // Distance filter - always apply
    result = result.filter(r => (r.distance || 0) <= maxDistance)
    
    // Band filter - if any selected, filter to those
    if (selectedBands.size > 0) {
      result = result.filter(r => r.band && selectedBands.has(r.band))
    }
    
    // Mode filter - if any selected, filter to those (repeater must have at least one selected mode)
    if (selectedModes.size > 0) {
      result = result.filter(r => r.modes?.some(m => selectedModes.has(m)))
    }
    
    // Sort
    if (sortBy === 'frequency') {
      result.sort((a, b) => parseFloat(a.Frequency) - parseFloat(b.Frequency))
    } else {
      result.sort((a, b) => (a.distance || 999) - (b.distance || 999))
    }
    
    return result
  }, [repeaters, selectedBands, selectedModes, sortBy, maxDistance])

  // Clear all filters
  const clearFilters = () => {
    setSelectedBands(new Set())
    setSelectedModes(new Set())
    setMaxDistance(50)
  }

  // Listen for data from server
  useEffect(() => {
    const offRepeaters = deskthing.on('repeaters', (data: any) => {
      if (data?.payload && Array.isArray(data.payload)) {
        setRepeaters(data.payload)
        setLoading(false)
        setError(null)
      }
    })

    const offLocation = deskthing.on('location', (data: any) => {
      if (data?.payload) {
        setLocation(data.payload)
      }
    })

    const offError = deskthing.on('error', (data: any) => {
      if (data?.payload?.message) {
        setError(data.payload.message)
        setLoading(false)
      }
    })

    // Request initial data
    setTimeout(() => {
      deskthing.send({ type: 'get', request: 'repeaters' })
    }, 500)

    return () => {
      offRepeaters()
      offLocation()
      offError()
    }
  }, [])

  // Error state - show configuration needed
  if (error && repeaters.length === 0) {
    return (
      <div className="h-screen w-screen bg-gradient-to-b from-gray-900 to-gray-950 text-white flex flex-col items-center justify-center p-6">
        <div className="text-6xl mb-6">⚙️</div>
        <h1 className="text-3xl font-bold mb-4 text-center">Setup Required</h1>
        <div className="bg-gray-800 rounded-xl p-6 max-w-md text-center">
          <p className="text-gray-300 text-lg mb-4">{error}</p>
          <div className="bg-blue-900/50 rounded-lg p-4 text-base text-blue-200">
            <p className="font-semibold mb-3">📋 To configure:</p>
            <ol className="text-left space-y-2">
              <li>1. Open DeskThing on your PC</li>
              <li>2. Go to Apps → Repeater Thing</li>
              <li>3. Click Settings (gear icon)</li>
              <li>4. Enter your email address</li>
              <li>5. Set your ZIP code</li>
            </ol>
          </div>
        </div>
        <p className="text-gray-500 text-sm mt-6">
          Email is required by RepeaterBook API terms of service
        </p>
      </div>
    )
  }

  // Loading state
  if (loading) {
    return (
      <div className="h-screen w-screen bg-gradient-to-b from-gray-900 to-gray-950 text-white flex flex-col items-center justify-center">
        <div className="text-6xl mb-4">📻</div>
        <div className="text-2xl font-semibold mb-2">Loading Repeaters...</div>
        <div className="text-gray-400 text-lg">Fetching data</div>
      </div>
    )
  }

  const hasActiveFilters = selectedBands.size > 0 || selectedModes.size > 0 || maxDistance !== 50

  return (
    <div className="h-screen w-screen bg-gradient-to-b from-gray-900 to-gray-950 text-white flex flex-col overflow-hidden">
      {/* Header - Large Filter button on LEFT */}
      <div className="flex-shrink-0 bg-gray-800/90 border-b border-gray-700 backdrop-blur-sm">
        <div className="p-3 flex items-center gap-3">
          {/* LARGE filter button on the left */}
          <button
            onClick={() => setShowFilters(true)}
            className={`flex items-center justify-center gap-2 px-6 py-4 rounded-xl text-xl font-bold transition-all min-w-[120px] ${
              hasActiveFilters
                ? 'bg-blue-600 text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
            </svg>
            {hasActiveFilters ? 'Filtered' : 'Filter'}
          </button>
          
          {/* Title and count */}
          <div className="flex-1 flex items-center gap-2">
            <span className="text-2xl">📻</span>
            <div>
              <span className="font-bold text-3xl">{filteredRepeaters.length}</span>
              <span className="text-gray-400 text-lg ml-2">
                / {maxDistance}mi
              </span>
            </div>
          </div>
          
          {/* Location indicator */}
          <div className="text-base text-gray-400 text-right">
            {location?.city ? `${location.city}, ${location.state}` : location?.state}
          </div>
        </div>
      </div>

      {/* Filter Modal */}
      {showFilters && (
        <FilterModal
          onClose={() => setShowFilters(false)}
          sortBy={sortBy}
          setSortBy={setSortBy}
          maxDistance={maxDistance}
          setMaxDistance={setMaxDistance}
          selectedBands={selectedBands}
          toggleBand={toggleBand}
          selectedModes={selectedModes}
          toggleMode={toggleMode}
          availableBands={availableBands}
          availableModes={availableModes}
          clearFilters={clearFilters}
          hasActiveFilters={hasActiveFilters}
        />
      )}

      {/* Error banner if there's an error but we have data */}
      {error && repeaters.length > 0 && (
        <div className="bg-yellow-900/50 border-b border-yellow-700 px-4 py-3 text-yellow-200 text-base">
          ⚠️ {error}
        </div>
      )}

      {/* Repeater List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {filteredRepeaters.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🔍</div>
            <p className="text-gray-400 text-xl mb-2">No repeaters found</p>
            <p className="text-gray-500 text-base mb-4">
              {repeaters.length > 0 
                ? `Try increasing distance or changing filters`
                : 'Waiting for data...'}
            </p>
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="px-6 py-3 bg-blue-600 rounded-xl hover:bg-blue-500 transition-all text-base font-semibold"
              >
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          filteredRepeaters.map((repeater, index) => (
            <RepeaterCard 
              key={`${repeater.Callsign}-${index}`} 
              repeater={repeater} 
              onClick={() => setSelectedRepeater(repeater)}
            />
          ))
        )}
      </div>

      {/* Repeater Detail Modal */}
      {selectedRepeater && (
        <RepeaterDetail 
          repeater={selectedRepeater} 
          onClose={() => setSelectedRepeater(null)} 
        />
      )}

      {/* Footer Attribution */}
      <div className="flex-shrink-0 bg-gray-900 border-t border-gray-800 px-4 py-2">
        <p className="text-sm text-gray-500 text-center">
          Data from RepeaterBook.com
        </p>
      </div>
    </div>
  )
}

export default App
